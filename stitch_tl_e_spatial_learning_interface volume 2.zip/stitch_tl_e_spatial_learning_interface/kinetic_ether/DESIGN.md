---
name: Kinetic Ether
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#ccc3d8'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#958da1'
  outline-variant: '#4a4455'
  surface-tint: '#d2bbff'
  primary: '#d2bbff'
  on-primary: '#3f008e'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#732ee4'
  secondary: '#ffb3b6'
  on-secondary: '#68001a'
  secondary-container: '#cc003c'
  on-secondary-container: '#ffdcdc'
  tertiary: '#bbc7dd'
  on-tertiary: '#253142'
  tertiary-container: '#5b677a'
  on-tertiary-container: '#dae6fd'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#ffdada'
  secondary-fixed-dim: '#ffb3b6'
  on-secondary-fixed: '#40000c'
  on-secondary-fixed-variant: '#920028'
  tertiary-fixed: '#d7e3fa'
  tertiary-fixed-dim: '#bbc7dd'
  on-tertiary-fixed: '#101c2c'
  on-tertiary-fixed-variant: '#3c475a'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
  mono-ui:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1440px
  margin-desktop: 64px
  margin-mobile: 20px
  gutter: 24px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style
The design system is a high-fidelity, spatial interface designed for an elite educational ecosystem. It merges the clarity of **Minimalism** with the structural depth of **Spatial UI**, creating an immersive environment that feels both advanced and serene.

The aesthetic focuses on "Digital Weight"—where elements have a physical presence in a 3D space without relying on skeuomorphism. It utilizes selective **Glassmorphism** to establish a sense of hierarchy and transparency, suggesting an open, interconnected platform. The emotional response is one of calm focus, technological sophistication, and premium reliability.

## Colors
The palette is rooted in a deep, nocturnal foundation to emphasize depth and focus. 

- **Primary (Electric Violet):** Used for "Teach Devta" AI identity, active states, and high-importance CTA paths. It represents intelligence and modern technology.
- **Secondary (Crimson):** Reserved for "Earn" moments, urgent notifications, or high-energy metrics.
- **Foundation:** Deep Charcoal (#121212) serves as the infinite canvas, while Off-White (#F8F9FA) provides sharp, high-contrast readability for body text.
- **Gradients:** Use "Void Gradients"—subtle transitions from Primary to transparent, or Primary to a slightly deeper shade. Avoid multi-hue rainbows; stick to monochromatic depth.

## Typography
The typography strategy leverages a trio of contemporary sans-serifs to distinguish between expression and function.

- **Hanken Grotesk** is used for large-scale displays and headlines to provide a sharp, geometric, and premium feel.
- **Inter** handles the heavy lifting of body copy, ensuring maximum legibility across all learning materials and complex data views.
- **Geist** (Monospaced style) is utilized for technical UI elements, labels, and "Earn" statistics to reinforce the technological narrative of the platform.

Maintain tight letter-spacing for large headlines to create a "compact-premium" look, while keeping body copy neutral and airy.

## Layout & Spacing
This design system uses a **Spatial Grid** model. While it follows a 12-column structure for alignment, the layout philosophy is built on "Floating Planes."

- **Layered Depth:** Elements should not sit flat on the background. Use generous vertical padding (`stack-lg`) to allow elements to breathe within their 3D planes.
- **Floating Navigation:** The navbar is never pinned to the top of the browser; it floats with a 24px margin from the screen edges.
- **Safe Areas:** On mobile, margins reduce to 20px, and complex 3D-stacked cards should reflow into vertical stacks with reduced perspective tilt.

## Elevation & Depth
Elevation is the primary tool for hierarchy. Rather than standard drop shadows, this design system uses **Layered Perspective**:

1.  **Level 0 (Canvas):** Deep Charcoal (#121212).
2.  **Level 1 (Submerged):** Subtle, dark containers with a 1px border (#ffffff10).
3.  **Level 2 (Floating):** Surfaces with a backdrop blur (20px) and a soft, diffused "Outer Glow" in the Primary color (at 5-10% opacity) instead of a black shadow.
4.  **Level 3 (Interactive):** Elements that lift on hover using a subtle CSS `translateY(-8px)` and a secondary, sharper shadow to simulate proximity to the user.

**Glassmorphism Specs:** Background blurs should be high (20px+) but the fill opacity should remain low (approx 4-8%) to ensure the UI feels light and spatial rather than heavy and milky.

## Shapes
The shape language is "Defined Softness." Elements use a consistent 0.5rem (8px) radius for base components, scaling up to 1.5rem (24px) for large spatial panels. 

Avoid pill shapes for buttons; stick to the `rounded-lg` (1rem/16px) standard to maintain a sophisticated, architectural feel. The corners represent the intersection of human-centric design and technological precision.

## Components

### Navbar (Floating Glass)
- **Style:** Detached from edges, 80px height, 24px margin from top.
- **Effect:** 30px Backdrop blur, 1px top border (#ffffff15).
- **Behavior:** Shrinks slightly on scroll; transitions from transparent to glass.

### 3D-Interactive Cards
- **Structure:** Layered stack. Background is a dark glass panel, foreground contains text/actions.
- **Interaction:** On hover, use a 5-degree tilt effect (Tilt.js style) and increase the intensity of the Primary color glow.
- **Content:** Project/Teacher images should have a subtle parallax movement relative to the card frame.

### Teach Devta AI Identity
- **Visual:** A central, morphing gradient sphere or high-quality 3D mesh. 
- **Style:** Incorporate a "Violet Pulse" animation. All AI-driven insights or chat interfaces should be housed in a unique "Aura" glass panel with a thin #7C3AED stroke.

### Modern Forms & Buttons
- **Primary Button:** Solid #7C3AED with a subtle inner glow. Text is bold white.
- **Secondary/Ghost:** 1px border (#8E9AAF) with no fill. Fill appears on hover.
- **Inputs:** Minimalist bottom-border only or very subtle submerged boxes. Focus state triggers a 2px Primary color underline and a soft glow.

### Progress & Stats
- **Visuals:** Thin, neon-style lines for graphs. 
- **Earn Indicators:** Use the Secondary (Crimson) color for monetary growth, featuring animated counters and "Spring-physics" bars that overshoot slightly before settling.